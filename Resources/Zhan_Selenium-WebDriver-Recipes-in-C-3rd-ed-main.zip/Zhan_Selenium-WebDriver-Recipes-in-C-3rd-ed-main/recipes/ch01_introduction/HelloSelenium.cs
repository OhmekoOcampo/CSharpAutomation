namespace SeleniumRecipes;
using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

public class HelloSelenium {
  public static void main(String[] args) {
    IWebDriver driver = new ChromeDriver();
    // System.Threading.Thread.Sleep(10000);
  }
}





