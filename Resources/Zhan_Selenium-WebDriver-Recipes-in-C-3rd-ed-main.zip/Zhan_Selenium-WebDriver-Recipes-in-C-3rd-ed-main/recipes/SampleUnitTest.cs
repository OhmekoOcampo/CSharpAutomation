namespace HelloSeleniumTest;

[TestClass]
public class SampleUnitTest
{
    [TestMethod]
    public void SampleTestCase1()
    {
        Console.Write("In Testing 1");
    }

    [TestMethod]
    public void SampleTestCase2()
    {
        Console.Write("In Testing 2");
    }
}